db_user = 'CHANGE_ME'
db_password = 'CHANGE_ME'
db_ip = '127.0.0.1'
db_connection_string = f'postgresql://{db_user}:{db_password}@{db_ip}:5432/'
db_name = 'UGSTank'

local_ust_path = r'C:\path\to\ust\state\data\\'
